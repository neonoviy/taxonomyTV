<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8d5b743012fa198e7c8d1f82dccca7e6',
      'native_key' => 'taxonomytv',
      'filename' => 'modNamespace/9745633dda5e58d3e699d6320d46a8c6.vehicle',
      'namespace' => 'taxonomytv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '76dcb9157394397d35b0d206dfde72d9',
      'native_key' => 22,
      'filename' => 'modPlugin/443583858fe91080588b3922d5f8bdcf.vehicle',
      'namespace' => 'taxonomytv',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5c63bd778b20877b18e3b49cd6e6b2a7',
      'native_key' => 1,
      'filename' => 'modCategory/37c62920b0cbaa33d9fc0440968cc56b.vehicle',
      'namespace' => 'taxonomytv',
    ),
  ),
);