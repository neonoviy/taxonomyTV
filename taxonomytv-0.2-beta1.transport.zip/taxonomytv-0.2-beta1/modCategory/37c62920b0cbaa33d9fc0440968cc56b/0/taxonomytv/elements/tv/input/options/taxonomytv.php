<?php
/**
 * @package modx
 * @subpackage processors.element.tv.renders.mgr.inputproperties
 */
return $modx->controller->fetchTemplate($this->modx->getOption('core_path').'components/taxonomytv/elements/tv/input/tpl/taxonomytvprops.tpl');